export const book_search_condition_keys = ['title', 'author', 'genre']

export const book_filter_keys = [
  'title',
  'author',
  'genre',
  'publication_date',
  'searchTerm',
]
