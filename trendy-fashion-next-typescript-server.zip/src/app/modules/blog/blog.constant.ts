export const blog_search_condition_keys = ['title', 'add_by_name']

export const blog_filter_keys = ['title', 'searchTerm']
