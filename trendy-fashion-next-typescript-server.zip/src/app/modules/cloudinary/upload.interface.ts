export type IUploadFile = {
  allowedFileTypes?: string[]
  errorMessage?: string
  maxFileSize?: number
}
