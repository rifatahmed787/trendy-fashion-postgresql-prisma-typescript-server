import express, { Application } from 'express'
import cors from 'cors'
import { PrismaClient } from '@prisma/client'
import AllRoutes from './routes/index'

const prisma = new PrismaClient()
const app: Application = express()
const port = process.env.PORT || 3000

// Middleware
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// Routes
app.use('/api/v1/', AllRoutes)

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`)
})

// Graceful shutdown
process.on('SIGINT', () => {
  prisma.$disconnect()
  process.exit(0)
})
