export const user_role = ['seller', 'buyer', 'admin']

export const pagination_keys = ['page', 'limit', 'sortBy', 'sortOrder']

export const locations = [
  'Dhaka',
  'Chattogram',
  'Barishal',
  'Rajshahi',
  'Sylhet',
  'Comilla',
  'Rangpur',
  'Mymensingh',
]
