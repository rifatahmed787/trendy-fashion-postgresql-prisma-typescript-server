import { prisma } from '../config/database'
import bcrypt from 'bcrypt'
import { Request } from 'express'

async function registerUser(data: UserRegistrationData) {
  // Hash the user's password before storing it
  const hashedPassword = await bcrypt.hash(data.password, 10)

  try {
    const user = await prisma.user.create({
      data: {
        username: data.username,
        email: data.email,
        password: hashedPassword,
      },
    })

    return user
  } catch (error) {
    throw new Error('Registration failed')
  }
}

async function loginUser(data: UserLoginData) {
  const user = await prisma.user.findUnique({
    where: {
      email: data.email,
    },
  })

  if (!user) {
    throw new Error('User not found')
  }

  const passwordMatch = await bcrypt.compare(data.password, user.password)

  if (!passwordMatch) {
    throw new Error('Incorrect password')
  }

  return user
}

function getUserIdFromRequest(req: Request) {
  // Implement a function to extract the user's ID from the request,
  // for example, using a JWT token.
}

export const authService = {
  registerUser,
  loginUser,
  getUserIdFromRequest,
}
